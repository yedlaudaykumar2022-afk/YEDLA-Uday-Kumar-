const mongoose = require("mongoose");

const deptSchema = new mongoose.Schema({
  name: String,
  hod_id: { type: mongoose.Schema.Types.ObjectId, ref: "Staff" }
});

module.exports = mongoose.model("Department", deptSchema);
