const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  name: String,
  age: Number,
  department_id: { type: mongoose.Schema.Types.ObjectId, ref: "Department" },
  books: [{ type: mongoose.Schema.Types.ObjectId, ref: "Book" }],
  mentor_id: { type: mongoose.Schema.Types.ObjectId, ref: "Staff" }
});

module.exports = mongoose.model("Student", studentSchema);
