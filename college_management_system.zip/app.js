const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const Student = require("./models/Student");

const app = express();
app.use(bodyParser.json());

mongoose.connect("mongodb://127.0.0.1:27017/collegeDB")
.then(() => console.log("DB Connected"))
.catch(err => console.log(err));

// CREATE
app.post("/students", async (req, res) => {
  const student = new Student(req.body);
  await student.save();
  res.send(student);
});

// READ
app.get("/students", async (req, res) => {
  const students = await Student.find()
    .populate("department_id")
    .populate("books")
    .populate("mentor_id");
  res.send(students);
});

// UPDATE
app.put("/students/:id", async (req, res) => {
  const updated = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.send(updated);
});

// DELETE
app.delete("/students/:id", async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.send("Deleted");
});

app.listen(3000, () => console.log("Server running on port 3000"));
